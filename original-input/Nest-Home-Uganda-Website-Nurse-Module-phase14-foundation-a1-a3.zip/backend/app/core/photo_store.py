"""Cloudinary signing and deletion helpers for private care-photo workflows.

All Cloudinary-specific URL and signature handling stays in this module so the
rest of the application does not construct provider URLs or leak API secrets.
"""
from __future__ import annotations

from hashlib import sha1
from typing import Any

import httpx

from app.core.config import Settings

PHOTO_FOLDER = "nest-home-care/visit-proof"
ALLOWED_IMAGE_TYPES = frozenset({"image/jpeg", "image/png", "image/webp"})


def upload_signature(settings: Settings, *, public_id: str, timestamp: int, folder: str = PHOTO_FOLDER) -> dict[str, Any]:
    """Return the signed upload fields required by Cloudinary's unsigned client flow."""
    if not settings.cloudinary_cloud_name or not settings.cloudinary_api_key or not settings.cloudinary_api_secret:
        raise ValueError("Photo storage is not configured")
    if not public_id or any(char in public_id for char in "\\/?#"):
        raise ValueError("Invalid photo identifier")
    if folder != PHOTO_FOLDER:
        raise ValueError("Unsupported photo folder")
    signing_text = f"folder={folder}&public_id={public_id}&timestamp={timestamp}{settings.cloudinary_api_secret}"
    signature = sha1(signing_text.encode("utf-8")).hexdigest()
    return {
        "cloud_name": settings.cloudinary_cloud_name,
        "api_key": settings.cloudinary_api_key,
        "timestamp": timestamp,
        "folder": folder,
        "public_id": public_id,
        "signature": signature,
        "upload_url": f"https://api.cloudinary.com/v1_1/{settings.cloudinary_cloud_name}/image/upload",
    }


async def delete_asset(settings: Settings, public_id: str, *, timeout_seconds: float = 10.0) -> bool:
    """Delete a photo asset; an already-absent asset is treated as idempotent success."""
    if not settings.cloudinary_cloud_name or not settings.cloudinary_api_key or not settings.cloudinary_api_secret:
        raise ValueError("Photo storage is not configured")
    if not public_id or not public_id.startswith(f"{PHOTO_FOLDER}/"):
        raise ValueError("Photo identifier is outside the approved folder")
    timestamp = __import__("time").time_ns() // 1_000_000_000
    signing_text = f"public_id={public_id}&timestamp={timestamp}{settings.cloudinary_api_secret}"
    signature = sha1(signing_text.encode("utf-8")).hexdigest()
    endpoint = f"https://api.cloudinary.com/v1_1/{settings.cloudinary_cloud_name}/image/destroy"
    async with httpx.AsyncClient(timeout=timeout_seconds) as client:
        response = await client.post(
            endpoint,
            data={"public_id": public_id, "timestamp": timestamp, "api_key": settings.cloudinary_api_key, "signature": signature},
        )
    response.raise_for_status()
    result = response.json().get("result")
    return result in {"ok", "not found"}


async def verify_asset(settings: Settings, public_id: str, *, timeout_seconds: float = 10.0) -> dict[str, Any]:
    """Verify that a signed upload exists in the approved Cloudinary folder."""
    from urllib.parse import quote

    if not settings.cloudinary_cloud_name or not settings.cloudinary_api_key or not settings.cloudinary_api_secret:
        raise ValueError("Photo storage is not configured")
    if not public_id or not public_id.startswith(f"{PHOTO_FOLDER}/"):
        raise ValueError("Photo identifier is outside the approved folder")
    endpoint = f"https://api.cloudinary.com/v1_1/{settings.cloudinary_cloud_name}/resources/image/upload/{quote(public_id, safe='/')}"
    async with httpx.AsyncClient(timeout=timeout_seconds, auth=(settings.cloudinary_api_key, settings.cloudinary_api_secret)) as client:
        response = await client.get(endpoint)
    if response.status_code == 404:
        raise LookupError("Cloudinary asset was not found")
    response.raise_for_status()
    data = response.json()
    if data.get("public_id") != public_id or data.get("resource_type") != "image":
        raise ValueError("Cloudinary asset metadata did not match the registered photo")
    return {"public_id": public_id, "bytes": int(data.get("bytes", 0)), "format": data.get("format", ""), "width": int(data.get("width", 0)), "height": int(data.get("height", 0))}
