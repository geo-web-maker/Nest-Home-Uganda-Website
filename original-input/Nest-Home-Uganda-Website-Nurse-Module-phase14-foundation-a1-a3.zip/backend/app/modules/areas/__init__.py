"""Area content module."""
