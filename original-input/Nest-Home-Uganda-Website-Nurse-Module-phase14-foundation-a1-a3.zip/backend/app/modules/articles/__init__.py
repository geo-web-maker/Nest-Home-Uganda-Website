"""Article content module."""
