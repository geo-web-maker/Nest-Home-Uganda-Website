"""Administrative activity log."""
