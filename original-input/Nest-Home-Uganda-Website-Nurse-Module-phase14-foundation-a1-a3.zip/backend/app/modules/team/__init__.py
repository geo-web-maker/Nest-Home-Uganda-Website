"""Team member content module."""
