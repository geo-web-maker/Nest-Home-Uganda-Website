"""Generic inbox and push dispatcher. Messages contain no client or clinical details."""
from datetime import UTC, datetime
from app.core.config import get_settings
from app.modules.care_ops.models import CareInboxNotification
from app.modules.nurses.models import Device
from app.modules.push.fcm import send_push

async def dispatch(user_ids: list[str], category: str, title: str, body: str, data: dict[str,str] | None=None, *, critical=False):
    results=[]; settings=get_settings()
    for user_id in sorted(set(user_ids)):
        notification=CareInboxNotification(id=f'{user_id}:{category}:{int(datetime.now(UTC).timestamp())}',user_id=user_id,category=category,title=title,body=body)
        await notification.insert()
        devices=await Device.find(Device.user_id==user_id,Device.revoked_at==None).to_list()  # noqa: E711
        for device in devices:
            if device.push_token:
                try: sent=await send_push(device.push_token,title,body,data,critical=critical)
                except Exception: sent=False
                results.append({'user_id':user_id,'device_id':device.device_id,'sent':sent})
    return results
