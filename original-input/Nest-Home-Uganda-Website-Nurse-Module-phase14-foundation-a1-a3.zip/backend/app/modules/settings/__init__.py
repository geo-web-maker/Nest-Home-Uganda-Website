"""Site settings module."""
