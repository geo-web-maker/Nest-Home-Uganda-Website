"""Admin care API. Every write is scoped and audited; reach is server-derived."""
from datetime import UTC, date, datetime, timedelta
from uuid import uuid4
from app.core.config import get_settings
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
import csv
import io
from pydantic import BaseModel, Field
from app.core.deps import Principal, ReachContext, get_care_actor, require_scopes, reach_filter
from app.core.db import get_care_database
from app.modules.audit.models import AuditLog
from app.modules.care_clients.models import CareClient
from app.modules.places.models import CarePlace, PlaceStay
from app.modules.visits.models import Visit, VisitEvent, VisitNote, VisitAnnotation, VisitPhoto, VisitSyncTombstone
from app.modules.flags.models import VisitFlag
from app.modules.visits.rules import make_snapshot, validate_schedule, VisitRuleError
from app.modules.settings.care_keys import CARE_SETTINGS
from app.modules.settings.care_service import care_values, save_care_value, care_setting_sources, reset_care_value
from app.modules.settings.rules import resolve_sos_enabled
from app.modules.nurses.models import NurseProfile
from app.modules.auth.models import User
router=APIRouter(prefix='/admin/care',tags=['admin-care'])
class ClientIn(BaseModel):
    id: str = Field(min_length=8,max_length=160)
    display_name: str = Field(min_length=1,max_length=120)
    notes_for_nurse: str = Field(default='',max_length=280)
    supervisor_id: str | None = None
    assigned_nurse_ids: list[str] = Field(default_factory=list)
    photo_allowed: bool = False
class PlaceIn(BaseModel):
    id: str = Field(min_length=8,max_length=160)
    label: str = Field(default='Home',max_length=80)
    address_text: str = Field(min_length=1,max_length=300)
    lat: float = Field(ge=-90,le=90)
    lng: float = Field(ge=-180,le=180)
    radius_m: int = Field(default=150,ge=50,le=1000)
    is_primary: bool = False
class StayIn(BaseModel):
    id: str = Field(min_length=8, max_length=160)
    place_id: str = Field(min_length=8, max_length=160)
    starts_on: date
class VisitIn(BaseModel):
    id: str = Field(min_length=8,max_length=160)
    client_id: str
    nurse_id: str
    place_id: str
    scheduled_start: datetime
    scheduled_end: datetime
    instructions: str = Field(default='',max_length=1000)
    confirm_overlap: bool = False
    adhoc: bool = False
class ReasonIn(BaseModel): reason: str = Field(min_length=3,max_length=500)
class AnnotateIn(BaseModel): comment: str = Field(min_length=3,max_length=1000)
class SettingIn(BaseModel): value: object

async def _audit(actor,action,kind,item_id,before=None,after=None):
    await AuditLog(action=action,item_type=kind,item_id=item_id,before=before,after=after).insert()
async def _client_reachable(client,ctx):
    if ctx.is_superadmin or ctx.reach=='all': return True
    if ctx.reach=='team': return client.supervisor_id==ctx.user_id or bool(set(client.assigned_nurse_ids)&set(ctx.team_nurse_ids))
    return ctx.user_id in client.assigned_nurse_ids
async def _visit_reachable(visit,ctx):
    return ctx.is_superadmin or ctx.reach=='all' or (ctx.reach=='own' and visit.nurse_id==ctx.user_id) or (ctx.reach=='team' and (visit.nurse_id in ctx.team_nurse_ids or visit.supervisor_id==ctx.user_id))

@router.get('/readiness')
async def readiness(_: Principal=Depends(require_scopes('carecfg:read'))):
    values=await care_values(); sos,reason=resolve_sos_enabled(values)
    checks=[]
    for key,spec in CARE_SETTINGS.items():
        if not spec.required_before_go_live: continue
        value=values.get(key,spec.default); status='set' if value not in ('',None,[],False) else ('default' if spec.default not in ('',None,[],False) else 'missing')
        if key.startswith('sos.') and key=='sos.enabled' and not sos: status='missing'
        checks.append({'id':key,'label':key.replace('.',' ').replace('_',' ').title(),'blocking':spec.required_before_go_live,'status':status,'detail':reason if key=='sos.enabled' else ''})
    profiles=await NurseProfile.find().to_list(); supervisors={p.supervisor_id for p in profiles if p.supervisor_id}
    checks.append({'id':'team.supervisor_and_nurse','label':'At least one supervisor has a nurse','blocking':True,'status':'set' if supervisors else 'missing','detail':''})
    if values.get('care.module_c_enabled'):
        for key,label,ready in [('sos.responder_configured','SOS responder configured',bool(values.get('sos.responder_configured'))),('sms.enabled','SMS enabled for SOS',bool(values.get('sms.enabled'))),('sos.emergency_numbers','Emergency numbers supplied',bool(values.get('sos.emergency_numbers'))),('frontend_url','Secure acknowledgement base URL configured',bool(get_settings().frontend_url))]:
            checks.append({'id':key,'label':label,'blocking':True,'status':'set' if ready else 'missing','detail':''})
    return {'ready':all(not c['blocking'] or c['status']=='set' for c in checks),'items':checks}

@router.get('/settings')
async def list_settings(_: Principal=Depends(require_scopes('carecfg:read'))):
    values=await care_values(); sources=await care_setting_sources(); return {'items':[{'id':k,'type':s.type,'value':values[k],'default':s.default,'source':sources[k],'required_before_go_live':s.required_before_go_live,'overridable_at':list(s.overridable_at),'group':s.group} for k,s in CARE_SETTINGS.items()]}
@router.put('/settings/{key}')
async def update_setting(key:str,payload:SettingIn,principal:Principal=Depends(require_scopes('carecfg:write'))):
    try: result=await save_care_value(key,payload.value,principal.user_id)
    except KeyError: raise HTTPException(404,detail='Unknown care setting')
    except ValueError as exc: raise HTTPException(422,detail=str(exc))
    return result

@router.delete('/settings/{key}')
async def reset_setting(key:str,principal:Principal=Depends(require_scopes('carecfg:write'))):
    try: return await reset_care_value(key,principal.user_id)
    except KeyError: raise HTTPException(404,detail='Unknown care setting')

@router.get('/clients')
async def clients(ctx:ReachContext=Depends(get_care_actor),_:Principal=Depends(require_scopes('clients:read'))):
    rows=await CareClient.find().to_list(); rows=[c for c in rows if await _client_reachable(c,ctx)]
    return {'items':[c.model_dump(exclude={'_id'}) for c in rows],'total':len(rows)}
@router.post('/clients',status_code=201)
async def create_client(body:ClientIn,principal:Principal=Depends(require_scopes('clients:write'))):
    row=CareClient(**body.model_dump()); await row.insert(); await _audit(principal,'care.client.create','care_client',row.id,None,body.model_dump()); return row
@router.get('/clients/{client_id}')
async def get_client(client_id:str,ctx:ReachContext=Depends(get_care_actor),_:Principal=Depends(require_scopes('clients:read'))):
    row=await CareClient.find_one(CareClient.id==client_id)
    if not row or not await _client_reachable(row,ctx): raise HTTPException(404,detail='Client not found')
    return row
@router.patch('/clients/{client_id}')
async def patch_client(client_id:str,body:dict,ctx:ReachContext=Depends(get_care_actor),principal:Principal=Depends(require_scopes('clients:write'))):
    row=await CareClient.find_one(CareClient.id==client_id)
    if not row or not await _client_reachable(row,ctx): raise HTTPException(404,detail='Client not found')
    before=row.model_dump(); allowed={'display_name','notes_for_nurse','status','assigned_nurse_ids','supervisor_id','photo_allowed'}
    for key,value in body.items():
        if key in allowed: setattr(row,key,value)
    row.updated_at=datetime.now(UTC); await row.save(); await _audit(principal,'care.client.update','care_client',client_id,before,row.model_dump()); return row
@router.get('/clients/{client_id}/places')
async def client_places(client_id:str,ctx:ReachContext=Depends(get_care_actor),_:Principal=Depends(require_scopes('places:read'))):
    client=await CareClient.find_one(CareClient.id==client_id)
    if not client or not await _client_reachable(client,ctx): raise HTTPException(404,detail='Client not found')
    return {'items':await CarePlace.find(CarePlace.client_id==client_id).to_list()}
@router.post('/clients/{client_id}/places',status_code=201)
async def create_place(client_id:str,body:PlaceIn,ctx:ReachContext=Depends(get_care_actor),principal:Principal=Depends(require_scopes('places:write'))):
    client=await CareClient.find_one(CareClient.id==client_id)
    if not client or not await _client_reachable(client,ctx): raise HTTPException(404,detail='Client not found')
    row=CarePlace(id=body.id,client_id=client_id,**body.model_dump(exclude={'id'}),geo={'type':'Point','coordinates':[body.lng,body.lat]}); await row.insert(); await _audit(principal,'care.place.create','care_place',row.id,None,body.model_dump()); return row
@router.patch('/places/{place_id}')
async def patch_place(place_id:str,body:dict,ctx:ReachContext=Depends(get_care_actor),principal:Principal=Depends(require_scopes('clients:write'))):
    row=await CarePlace.find_one(CarePlace.id==place_id)
    if not row: raise HTTPException(404,detail='Place not found')
    client=await CareClient.find_one(CareClient.id==row.client_id)
    if not client or not await _client_reachable(client,ctx): raise HTTPException(404,detail='Place not found')
    before=row.model_dump()
    for key in ('label','address_text','lat','lng','radius_m','is_primary'):
        if key in body: setattr(row,key,body[key])
    row.geo={'type':'Point','coordinates':[row.lng,row.lat]}; await row.save(); await _audit(principal,'care.place.update','care_place',place_id,before,row.model_dump()); return row
@router.get('/clients/{client_id}/stays')
async def client_stays(client_id:str,ctx:ReachContext=Depends(get_care_actor),_:Principal=Depends(require_scopes('clients:read'))):
    client=await CareClient.find_one(CareClient.id==client_id)
    if not client or not await _client_reachable(client,ctx): raise HTTPException(404,detail='Client not found')
    return {'items':await PlaceStay.find(PlaceStay.client_id==client_id).to_list()}
@router.post('/clients/{client_id}/stays',status_code=201)
async def move_client(client_id:str,body:StayIn,ctx:ReachContext=Depends(get_care_actor),principal:Principal=Depends(require_scopes('clients:write'))):
    client=await CareClient.find_one(CareClient.id==client_id)
    if not client or not await _client_reachable(client,ctx): raise HTTPException(404,detail='Client not found')
    place=await CarePlace.find_one(CarePlace.id==body.place_id, CarePlace.client_id==client_id)
    if not place: raise HTTPException(422,detail='Place must belong to the selected client')
    starts_on=body.starts_on.isoformat()
    open_stays=await PlaceStay.find(PlaceStay.client_id==client_id, PlaceStay.ends_on==None).to_list()  # noqa: E711
    if any(stay.starts_on >= starts_on for stay in open_stays):
        raise HTTPException(422,detail='A new stay must start after the current stay begins')
    row=PlaceStay(id=body.id,client_id=client_id,place_id=body.place_id,starts_on=starts_on,ends_on=None)
    db=get_care_database()
    async with await db.client.start_session() as session:
        async def write_transaction(active_session):
            for stay in open_stays:
                stay.ends_on=(body.starts_on-timedelta(days=1)).isoformat()
                await stay.save(session=active_session)
            await row.insert(session=active_session)
        await session.with_transaction(write_transaction)
    await _audit(principal,'care.client.move','place_stay',row.id,None,body.model_dump(mode='json')); return row

@router.get('/visits')
async def visits(ctx:ReachContext=Depends(get_care_actor),_:Principal=Depends(require_scopes('visits:read')),status:str|None=None,nurse_id:str|None=None,client_id:str|None=None,adhoc:bool|None=None,page:int=Query(1,ge=1),page_size:int=Query(50,ge=1,le=200)):
    rows=await Visit.find().sort('-scheduled_start').to_list(); rows=[v for v in rows if await _visit_reachable(v,ctx) and (not status or v.status==status) and (not nurse_id or v.nurse_id==nurse_id) and (not client_id or v.client_id==client_id) and (adhoc is None or v.adhoc==adhoc)]
    return {'items':[v.model_dump(exclude={'_id'}) for v in rows[(page-1)*page_size:page*page_size]],'total':len(rows),'page':page,'page_size':page_size}
@router.post('/visits',status_code=201)
async def create_visit(body:VisitIn,ctx:ReachContext=Depends(get_care_actor),principal:Principal=Depends(require_scopes('visits:write'))):
    client=await CareClient.find_one(CareClient.id==body.client_id); place=await CarePlace.find_one(CarePlace.id==body.place_id); profile=await NurseProfile.find_one(NurseProfile.user_id==body.nurse_id)
    if not client or not place or not profile or not profile.active or not await _client_reachable(client,ctx): raise HTTPException(404,detail='Client, place, or nurse not found in reach')
    if place.client_id!=client.id: raise HTTPException(422,detail='Place must belong to the client')
    if body.nurse_id not in client.assigned_nurse_ids: raise HTTPException(422,detail='Nurse must be assigned to this client')
    existing=await Visit.find(Visit.nurse_id==body.nurse_id).to_list()
    try: clashes=validate_schedule(body.scheduled_start,body.scheduled_end,body.client_id,{'client_id':place.client_id},body.nurse_id,[v.model_dump() for v in existing],body.confirm_overlap)
    except VisitRuleError as exc:
        msg=str(exc)
        if msg.startswith('nurse_busy:'): raise HTTPException(409,detail={'code':'nurse_busy','visit_ids':msg.split(':',1)[1].split(',')})
        raise HTTPException(422,detail=msg)
    row=Visit(id=body.id,client_id=body.client_id,nurse_id=body.nurse_id,supervisor_id=profile.supervisor_id,place_id=place.id,scheduled_start=body.scheduled_start,scheduled_end=body.scheduled_end,instructions=body.instructions,adhoc=body.adhoc,place_snapshot=make_snapshot(place.model_dump())); await row.insert(); await _audit(principal,'care.visit.create','visit',row.id,None,body.model_dump()); return row
@router.get('/visits/{visit_id}')
async def visit_detail(visit_id:str,ctx:ReachContext=Depends(get_care_actor),_:Principal=Depends(require_scopes('visits:read'))):
    row=await Visit.find_one(Visit.id==visit_id)
    if not row or not await _visit_reachable(row,ctx): raise HTTPException(404,detail='Visit not found')
    return {'visit':row,'events':await VisitEvent.find(VisitEvent.visit_id==visit_id).to_list(),'notes':await VisitNote.find(VisitNote.visit_id==visit_id).to_list(),'flags':await VisitFlag.find(VisitFlag.visit_id==visit_id).to_list(),'photos':await VisitPhoto.find(VisitPhoto.visit_id==visit_id).to_list(),'annotations':await VisitAnnotation.find(VisitAnnotation.visit_id==visit_id).to_list(),'audit':await AuditLog.find(AuditLog.item_id==visit_id).sort('-at').to_list()}
@router.patch('/visits/{visit_id}')
async def patch_visit(visit_id:str,body:dict,ctx:ReachContext=Depends(get_care_actor),principal:Principal=Depends(require_scopes('visits:write'))):
    row=await Visit.find_one(Visit.id==visit_id)
    if not row or not await _visit_reachable(row,ctx): raise HTTPException(404,detail='Visit not found')
    if row.status!='scheduled': raise HTTPException(409,detail='Only scheduled visits can be changed')
    before=row.model_dump()
    previous_nurse_id = row.nurse_id
    if 'nurse_id' in body:
        profile=await NurseProfile.find_one(NurseProfile.user_id==str(body['nurse_id']))
        if not profile or not profile.active: raise HTTPException(422,detail='Nurse must be active before assignment')
        if not ctx.is_superadmin and ctx.reach != 'all':
            allowed_ids = set(ctx.team_nurse_ids) if ctx.reach == 'team' else {ctx.user_id}
            if profile.user_id not in allowed_ids: raise HTTPException(404,detail='Nurse not found in your reach')
        client=await CareClient.find_one(CareClient.id==row.client_id)
        if not client or profile.user_id not in client.assigned_nurse_ids: raise HTTPException(422,detail='Nurse must be assigned to this client')
        row.nurse_id=profile.user_id
        row.supervisor_id=profile.supervisor_id
    if 'scheduled_start' in body or 'scheduled_end' in body:
        raise HTTPException(422,detail='Rescheduling requires the dedicated scheduling workflow')
    if 'instructions' in body: row.instructions=str(body['instructions'])[:1000]
    row.updated_at = datetime.now(UTC)
    if row.nurse_id != previous_nurse_id:
        tombstone = VisitSyncTombstone(id=uuid4().hex, nurse_id=previous_nurse_id, visit_id=visit_id, reason='reassigned', updated_at=row.updated_at)
        database = get_care_database()
        async with await database.client.start_session() as session:
            async def write_transaction(active_session):
                await row.save(session=active_session)
                await tombstone.insert(session=active_session)
            await session.with_transaction(write_transaction)
    else:
        await row.save()
    await _audit(principal,'care.visit.update','visit',visit_id,before,row.model_dump()); return row
@router.post('/visits/{visit_id}/cancel')
async def cancel_visit(visit_id:str,body:ReasonIn,ctx:ReachContext=Depends(get_care_actor),principal:Principal=Depends(require_scopes('visits:write'))):
    row=await Visit.find_one(Visit.id==visit_id)
    if not row or not await _visit_reachable(row,ctx): raise HTTPException(404,detail='Visit not found')
    if row.status in {'completed','cancelled'}: raise HTTPException(409,detail='Visit is terminal')
    before=row.model_dump(); now=datetime.now(UTC); row.status='cancelled'; row.updated_at=now
    tombstone = VisitSyncTombstone(id=uuid4().hex, nurse_id=row.nurse_id, visit_id=visit_id, reason='cancelled', updated_at=now)
    database = get_care_database()
    async with await database.client.start_session() as session:
        async def write_transaction(active_session):
            await row.save(session=active_session)
            await tombstone.insert(session=active_session)
        await session.with_transaction(write_transaction)
    await _audit(principal,'care.visit.cancel','visit',visit_id,before,{'status':'cancelled','reason':body.reason}); return {'id':visit_id,'status':'cancelled'}
@router.post('/visits/{visit_id}/annotate',status_code=201)
async def annotate(visit_id:str,body:AnnotateIn,ctx:ReachContext=Depends(get_care_actor),principal:Principal=Depends(require_scopes('visits:write'))):
    row=await Visit.find_one(Visit.id==visit_id)
    if not row or not await _visit_reachable(row,ctx): raise HTTPException(404,detail='Visit not found')
    annotation=VisitAnnotation(id=f'{visit_id}:{datetime.now(UTC).timestamp()}',visit_id=visit_id,user_id=principal.user_id,comment=body.comment); await annotation.insert(); await _audit(principal,'care.visit.annotate','visit',visit_id,None,{'comment':body.comment}); return annotation
@router.get('/flags')
async def flags(ctx:ReachContext=Depends(get_care_actor),_:Principal=Depends(require_scopes('flags:read'))):
    rows=await VisitFlag.find(VisitFlag.status=='open').sort('-raised_at').to_list(); ids={v.id for v in await Visit.find().to_list() if await _visit_reachable(v,ctx)}
    return {'items':[f for f in rows if f.visit_id in ids]}
@router.post('/flags/{flag_id}/resolve')
async def resolve_flag(flag_id:str,body:ReasonIn,ctx:ReachContext=Depends(get_care_actor),principal:Principal=Depends(require_scopes('flags:write'))):
    row=await VisitFlag.find_one(VisitFlag.id==flag_id)
    if not row: raise HTTPException(404,detail='Flag not found')
    row.status='resolved'; row.resolved_at=datetime.now(UTC); row.resolved_by=principal.user_id; row.resolution_note=body.reason; await row.save(); await _audit(principal,'care.flag.resolve','visit_flag',flag_id,None,{'reason':body.reason}); return row
@router.get('/team')
async def team(ctx:ReachContext=Depends(get_care_actor),_:Principal=Depends(require_scopes('visits:read'))):
    profiles=await NurseProfile.find().to_list(); allowed=[x for x in profiles if ctx.is_superadmin or ctx.reach=='all' or x.user_id in ctx.team_nurse_ids or x.user_id==ctx.user_id]
    today=date.today().isoformat(); return {'items':[{'user_id':x.user_id,'staff_number':x.staff_number,'active':x.active,'last_seen_at':x.last_seen_at} for x in allowed],'date':today}
@router.get('/reports/visits')
async def visit_report(ctx:ReachContext=Depends(get_care_actor),principal:Principal=Depends(require_scopes('care-reports:read')),format:str|None=None):
    if format=='csv' and not principal.has('care-reports:export'): raise HTTPException(403,detail='Missing care-reports:export')
    rows=await Visit.find().to_list(); rows=[v for v in rows if await _visit_reachable(v,ctx)]
    if format=='csv':
        from app.modules.care_ops.rules import csv_safe
        stream=io.StringIO(); writer=csv.writer(stream); writer.writerow(['Visit ID','Nurse ID','Client ID','Status','Scheduled start'])
        for visit in rows: writer.writerow([csv_safe(visit.id),csv_safe(visit.nurse_id),csv_safe(visit.client_id),csv_safe(visit.status),csv_safe(visit.scheduled_start.isoformat())])
        await _audit(principal,'care.report.export','visit_report',None,None,{'count':len(rows)})
        return StreamingResponse(iter([stream.getvalue()]),media_type='text/csv',headers={'Content-Disposition':'attachment; filename="care-visits.csv"'})
    return {'total':len(rows),'by_status':{s:sum(v.status==s for v in rows) for s in ('scheduled','in_progress','completed','cancelled','missed')},'items':[{'id':v.id,'nurse_id':v.nurse_id,'client_id':v.client_id,'status':v.status,'scheduled_start':v.scheduled_start} for v in rows]}
