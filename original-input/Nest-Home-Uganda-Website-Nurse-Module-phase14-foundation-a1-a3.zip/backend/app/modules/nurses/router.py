from datetime import UTC, datetime
from fastapi import APIRouter, Depends, HTTPException, status
from app.core.deps import Principal, ReachContext, get_care_actor, require_scopes
from app.core.errors import Conflict, NotFound, ValidationFailed
from app.modules.audit import service as audit
from app.modules.auth import repository as auth_repo
from app.modules.nurses.models import Device, NurseProfile
from app.modules.nurses.schemas import AdhocOverride, DeviceRegistration, NurseInvite, NursePatch, NurseProfileResponse, SupervisorPatch, DeviceRevocation
from app.modules.nurses.service import invite_nurse, patch_nurse, profile_for_user, register_user_device
router = APIRouter(prefix='/admin/care/nurses', tags=['care-nurses'])
field_router = APIRouter(prefix='/field', tags=['field'])

def _nurse_is_in_reach(user_id: str, ctx: ReachContext) -> bool:
    if ctx.is_superadmin or ctx.reach == 'all':
        return True
    if ctx.reach == 'own':
        return user_id == ctx.user_id
    if ctx.reach == 'team':
        return user_id == ctx.user_id or user_id in ctx.team_nurse_ids
    return False

@router.get('', response_model=list[NurseProfileResponse])
async def list_nurses(ctx:ReachContext=Depends(get_care_actor), _:Principal=Depends(require_scopes('nurses:read'))):
    profiles=await NurseProfile.find().to_list()
    if not ctx.is_superadmin and ctx.reach!='all': profiles=[p for p in profiles if p.user_id in ctx.team_nurse_ids or p.user_id == ctx.user_id]
    return [NurseProfileResponse(user_id=p.user_id,staff_number=p.staff_number,supervisor_id=p.supervisor_id,team_id=p.team_id,active=p.active,phone_e164=p.phone_e164,last_seen_at=p.last_seen_at,app_version=p.app_version) for p in profiles]
@router.post('', response_model=NurseProfileResponse, status_code=201)
async def create_nurse(payload:NurseInvite, principal:Principal=Depends(require_scopes('nurses:write')), ctx:ReachContext=Depends(get_care_actor)):
    if not (ctx.is_superadmin or ctx.reach == 'all'):
        if ctx.reach != 'team' or payload.supervisor_id != ctx.user_id:
            raise HTTPException(status_code=404, detail='Nurse profile not found')
    if payload.supervisor_id:
        supervisor = await auth_repo.user_by_id(payload.supervisor_id)
        if supervisor is None or not supervisor.is_active:
            raise HTTPException(status_code=422, detail='Supervisor is not active')
        if not (ctx.is_superadmin or ctx.reach == 'all') and payload.supervisor_id != ctx.user_id:
            raise HTTPException(status_code=404, detail='Supervisor not found')
    try: profile=await invite_nurse(principal,payload)
    except (Conflict,ValidationFailed) as exc: raise HTTPException(getattr(exc,'status_code',422),detail=str(exc))
    return profile
@router.get('/{user_id}', response_model=NurseProfileResponse)
async def get_nurse_profile(user_id: str, ctx:ReachContext=Depends(get_care_actor), _: Principal = Depends(require_scopes('nurses:read'))):
    profile = await profile_for_user(user_id)
    if profile is None or (not ctx.is_superadmin and ctx.reach!='all' and profile.user_id not in ctx.team_nurse_ids and profile.user_id != ctx.user_id):
        raise HTTPException(status_code=404, detail='Nurse profile not found')
    return profile
@router.patch('/{user_id}', response_model=NurseProfileResponse)
async def update_nurse(user_id:str,payload:NursePatch,principal:Principal=Depends(require_scopes('nurses:write')),ctx:ReachContext=Depends(get_care_actor)):
    if not _nurse_is_in_reach(user_id, ctx):
        raise HTTPException(status_code=404, detail='Nurse profile not found')
    try: return await patch_nurse(principal,user_id,payload)
    except NotFound as exc: raise HTTPException(404,detail=str(exc))
    except (Conflict,ValidationFailed) as exc: raise HTTPException(422,detail=str(exc))
@router.patch('/{user_id}/supervisor',response_model=NurseProfileResponse)
async def change_supervisor(user_id:str,payload:SupervisorPatch,principal:Principal=Depends(require_scopes('nurses:write')),ctx:ReachContext=Depends(get_care_actor)):
    if not _nurse_is_in_reach(user_id, ctx):
        raise HTTPException(status_code=404, detail='Nurse profile not found')
    if payload.supervisor_id and not (ctx.is_superadmin or ctx.reach == 'all') and payload.supervisor_id != ctx.user_id:
        raise HTTPException(status_code=404, detail='Supervisor not found')
    profile=await NurseProfile.find_one(NurseProfile.user_id==user_id)
    if not profile: raise HTTPException(404,detail='Nurse profile not found')
    if payload.supervisor_id:
        supervisor=await auth_repo.user_by_id(payload.supervisor_id)
        if supervisor and not supervisor.is_active: supervisor=None
        if not supervisor: raise HTTPException(422,detail='Supervisor is not active')
    before={'supervisor_id':profile.supervisor_id}; profile.supervisor_id=payload.supervisor_id; await profile.save()
    await audit.record(principal,'nurse.supervisor.change','nurse_profile',user_id,user_id,before=before,after={'supervisor_id':profile.supervisor_id})
    return profile
@router.patch('/{user_id}/adhoc-override',response_model=NurseProfileResponse)
async def set_adhoc_override(user_id:str,payload:AdhocOverride,principal:Principal=Depends(require_scopes('carecfg:write')),ctx:ReachContext=Depends(get_care_actor)):
    if not _nurse_is_in_reach(user_id, ctx):
        raise HTTPException(status_code=404, detail='Nurse profile not found')
    profile=await NurseProfile.find_one(NurseProfile.user_id==user_id)
    if not profile: raise HTTPException(404,detail='Nurse profile not found')
    before={'adhoc_override':profile.adhoc_override}; profile.adhoc_override=payload.enabled; await profile.save()
    await audit.record(principal,'nurse.adhoc_override','nurse_profile',user_id,user_id,before=before,after={'adhoc_override':profile.adhoc_override})
    return profile
@router.post('/{user_id}/revoke-device')
async def revoke_device(user_id:str,body:DeviceRevocation,principal:Principal=Depends(require_scopes('nurses:write')),ctx:ReachContext=Depends(get_care_actor)):
    if not _nurse_is_in_reach(user_id, ctx):
        raise HTTPException(status_code=404, detail='Nurse profile not found')
    device=await Device.find_one(Device.device_id==body.device_id,user_id=user_id)
    if not device: raise HTTPException(404,detail='Device not found')
    device.revoked_at=datetime.now(UTC); await device.save(); await audit.record(principal,'nurse.device.revoke','device',device.device_id,device.device_id,after={'revoked_at':device.revoked_at.isoformat()}); return {'revoked':True}
@field_router.post('/devices', status_code=status.HTTP_201_CREATED)
async def register_device(payload: DeviceRegistration, principal: Principal = Depends(require_scopes('field:use'))):
    existing=await Device.find_one(Device.device_id==payload.device_id)
    if existing and existing.revoked_at: raise HTTPException(401,detail='device_revoked')
    if existing and existing.user_id != principal.user_id:
        raise HTTPException(status_code=409, detail='device_already_registered')
    try:
        device = await register_user_device(principal.user_id, payload)
    except Exception as exc:
        from app.core.errors import Conflict, Unauthorised
        if isinstance(exc, Conflict): raise HTTPException(status_code=409, detail='device_already_registered') from exc
        if isinstance(exc, Unauthorised): raise HTTPException(status_code=401, detail='device_revoked') from exc
        raise
    return {'device_id': device.device_id, 'registered': True}
