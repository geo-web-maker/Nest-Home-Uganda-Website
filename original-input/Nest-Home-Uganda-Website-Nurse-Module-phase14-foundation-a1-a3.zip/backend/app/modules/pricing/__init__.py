"""PricingBlock content module."""
