"""Media library module."""
