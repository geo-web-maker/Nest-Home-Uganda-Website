"""Dashboard aggregates."""
