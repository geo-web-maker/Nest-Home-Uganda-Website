export { EnquiryDetailPage } from './EnquiryDetailPage';
